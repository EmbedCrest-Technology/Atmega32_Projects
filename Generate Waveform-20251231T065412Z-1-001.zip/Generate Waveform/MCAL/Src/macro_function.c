/*
 * macro_function.c
 *
 * Created: 8/12/2024
 * Author: Embedcrest Technology Private Limited
 *
 */

#include "macro_function.h"

