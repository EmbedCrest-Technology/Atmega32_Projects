/*
 * TIMER.h
 *
 * Created: 21/10/2024   9.07 AM
 *  Author: Embedcrest Technology Private Limited
 */ 

#ifndef TIMER_H_
#define TIMER_H_

void TIMER0_CTC_init_with_interrupt(void);

#endif /* TIMER_H_ */
