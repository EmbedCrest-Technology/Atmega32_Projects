/*
 * DC_MOTOR.h
 *
 * Created: 20/10/2024  11.11 AM
 *  Author: Embedcrest Technology Private Limited
 */ 

#ifndef DC_MOTOR_H_
#define DC_MOTOR_H_

// No changes needed - already correct for servo control
void Servo_motor_with_TIMER1_fast_pwm_ICRA_wave(double angle);

#endif /* DC_MOTOR_H_ */
